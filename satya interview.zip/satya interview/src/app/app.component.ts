import { Component, ViewChild } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  public createUser:boolean=false;
  public users:any=[{
    Name:'Praveen',
    Email:'xyz@test.com',
    Phone:'123456789',
    Address:'xyz'
  },{
    Name:'Praveen',
    Email:'xyz@test.com',
    Phone:'123456789',
    Address:'xyz'
  },{
    Name:'Praveen',
    Email:'xyz@test.com',
    Phone:'123456789',
    Address:'xyz'
  },{
    Name:'Praveen',
    Email:'xyz@test.com',
    Phone:'123456789',
    Address:'xyz'
  }];
  constructor(){

  }

  public showmore(i){
    this.users[i]["showmore"]=true;
  }
  public showless(i)
  {
    this.users[i]["showmore"]=false;
  }
  public addUser(){
    var user={
      Name:document.getElementById("Name")["value"],
      Email:document.getElementById("Email")["value"],
      Phone:document.getElementById("Phone")["value"],
      Address:document.getElementById("Address")["value"]
    }
    this.users.push(user);
    this.createUser=false;
  }
  public showPopUP(){
    this.createUser=true;
  }
  }
